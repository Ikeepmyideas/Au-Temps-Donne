import React from 'react';
import '../css/admin.css'; 
import NavMenu from './navMenu'; 

function Dashboard() {
  return (
    <div className="dashboard-container">
      <NavMenu />
      
      <section className="main-content">
        <h1>Dashboard</h1>
      </section>
    </div>
  );
}

export default Dashboard;
